/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package myproject.task22;
import javax.swing.JOptionPane;

/**
 *
 * @author ruqay
 */
public class Task22 {

    public static void main(String[] args) {
       
        String name = JOptionPane.showInputDialog("Enter your name");
        int count = 0; 

        if (name != null) {
            
            for (int i = 0; i < name.length(); i++) {
                count++;
            }

            
            JOptionPane.showMessageDialog(null, name + " has " + count + " characters.", "Character Count", JOptionPane.PLAIN_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "No name entered.", "Error", JOptionPane.ERROR_MESSAGE);
        }}}

