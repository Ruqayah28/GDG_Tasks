/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package myproject.google_task2;
import java.util.Arrays;
import java.util.Scanner;
/**
 *
 * @author ruqay
 */
public class Google_task2 {

    public static void main(String[] args) {
        
        Hello_task var = new Hello_task();
        
        System.out.println("With var version: ");
        var.withVar();
        
        System.out.println("\nWithout var version: ");
        var.withOutVar();
        
        System.out.println("\nDifferent greetings version: ");
        var.differentGreeting();
        
        
     
    }
}
